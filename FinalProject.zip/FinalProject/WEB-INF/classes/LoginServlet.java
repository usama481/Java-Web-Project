import java.io.*;
import java.util.*;
import javax.swing.*;
import java.sql.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class LoginServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");
        UserDao ud = new UserDao();
        User u = ud.userLogin(email, password);

        if (u != null) {
            HttpSession session = request.getSession(true);
            session.setAttribute("userType", u.getuserType());
            session.setAttribute("email", u.getEmail());
            if (u.getuserType() == 1) {
                response.sendRedirect("admin.jsp");
            } else {

                response.sendRedirect("Student.jsp");
            }

        } else {

            response.sendRedirect("Login.jsp");
        }

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}
