import java.io.*;
import java.util.*;
import javax.swing.*;
import java.sql.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class IssueServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        BookDao bd = new BookDao();
        PrintWriter out = new PrintWriter(System.out);
        String email = request.getParameter("email");
        int id = Integer.parseInt(request.getParameter("id"));
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/lib_management";
            Connection con = DriverManager.getConnection(url, "root", "root");

            String q = "select * from signup where email=?";
            PreparedStatement ps = con.prepareStatement(q);
            ps.setString(1, email);

            ResultSet rs = ps.executeQuery();
            rs.next();
            int issued = rs.getInt("books");
            boolean u = false;
            if (issued < 2) {
                q = "UPDATE signup SET books=? WHERE email=?";
                ps = con.prepareStatement(q);
                ps.setInt(1, (issued + 1));
                ps.setString(2, email);
                ps.executeUpdate();
                u = bd.issueBook(id);
            }

            HttpSession session = request.getSession(true);
            if (u) {
                session.setAttribute("issued", "Book isuued");
                response.sendRedirect("admin.jsp");
            } else {
                session.setAttribute("Failed", "More than 2 books can't be issued.");
                response.sendRedirect("admin.jsp");
            }
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}
