// import java.io.*;
// import jakarta.servlet.http.*;
// import jakarta.servlet.*;
// import java.util.*;
// import java.sql.*;
// import javax.swing.*;

// public class ViewBooksServlet extends HttpServlet {
// public void doPost(HttpServletRequest request, HttpServletResponse response)
// throws ServletException, IOException {

// String title = request.getParameter("title");
// String author = request.getParameter("author");
// int quantity = Integer.parseInt(request.getParameter("quantity"));

// Book c = new Book(title, author, quantity);

// BookDao bdao = new BookDao();
// List<Book> f = bdao.ViewBooks(c);

// if (f != null) {
// HttpSession session = request.getSession();
// session.setAttribute("title", title);
// session.setAttribute("author", author);
// session.setAttribute("quantity", quantity);
// // response.sendRedirect("");
// }

// }
// }