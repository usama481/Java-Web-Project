import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BookDao {

    public boolean addBook(Book b) {
        boolean f = false;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/lib_management";
            Connection con = DriverManager.getConnection(url, "root", "root");

            String q = "insert into books(title,author,quantity) values (?,?,?)";
            PreparedStatement ps = con.prepareStatement(q);
            ps.setString(1, b.getTitle());
            ps.setString(2, b.getAuthor());
            ps.setInt(3, b.getQuantity());

            int i = ps.executeUpdate();

            if (i == 1) {
                f = true;
            }
            con.close();
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }

        return f;

    }

    public boolean issueBook(int id) {
        boolean f = false;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/lib_management";
            Connection con = DriverManager.getConnection(url, "root", "root");

            String q = "select * from books where id=?";
            PreparedStatement ps = con.prepareStatement(q);
            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();
            rs.next();
            int quantity = rs.getInt("quantity");
            if (quantity > 1) {
                q = "UPDATE books SET quantity=? WHERE id=?";
                ps = con.prepareStatement(q);
                ps.setInt(1, (quantity - 1));
                ps.setInt(2, id);
                ps.executeUpdate();
                f = true;
            }

            con.close();
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }

        return f;

    }
}

// public List<Book> ViewBooks(Book c) {
// List<Book> list = new ArrayList<Book>();
// Book b = null;
// try {
// Class.forName("com.mysql.jdbc.Driver");
// String url = "jdbc:mysql://127.0.0.1/lib_management";
// Connection con = DriverManager.getConnection(url, "root", "root");

// String q = "Select * from books";
// Statement st = con.createStatement();

// ResultSet rs = st.executeQuery(q);

// while (rs.next()) {
// b = new Book();
// b.setId(rs.getInt(1));
// b.setTitle(rs.getString(2));
// b.setAuthor(rs.getString(3));
// list.add(b);
// }
// con.close();
// } catch (ClassNotFoundException | SQLException ex) {
// ex.printStackTrace();
// }

// return list;

// }
